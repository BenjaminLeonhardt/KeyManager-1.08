// stdafx.h: Includedatei f�r Standardsystem-Includedateien
// oder h�ufig verwendete projektspezifische Includedateien,
// die nur in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once
#ifdef _WIN32
#include "targetver.h"
#include <tchar.h>
#include <windows.h>
#endif // _WIN32

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>

#include "AES.h"
#include "KeyManager.h"

// TODO: Hier auf zus�tzliche Header, die das Programm erfordert, verweisen.
